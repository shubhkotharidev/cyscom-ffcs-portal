import { useState, useEffect, useCallback } from "react";

import GlobalStyle from "./components/GlobalStyle";
import Landing, { PixelTransition } from "./components/Landing";
import Login from "./components/Login";
import Shell from "./components/Shell";
import Dashboard from "./components/Dashboard";
import Departments from "./components/Departments";
import Projects from "./components/Projects";
import Leaderboard from "./components/Leaderboard";
import SuperAdmin from "./components/SuperAdmin";
import Admin from "./components/Admin";

const MOCK_USERS = [
  { email: "admin@vitstudent.ac.in", name: "ADMIN USER", role: "admin", regNo: "21BCE0001", points: 120, departments: ["tech", "webdev"], locked: true, contributions: [] },
  { email: "super@vitstudent.ac.in", name: "SUPER ADMIN", role: "super_admin", regNo: "21BCE0000", points: 500, departments: [], locked: true, contributions: [] },
  { email: "test@example.com", name: "TEST MEMBER", role: "member", regNo: "22BCE1234", points: 45, departments: ["events", "social"], locked: true, contributions: [
    { title: "Designed Banner", points: 15, date: "2023-10-01", isRejected: false },
    { title: "Helped in Registration", points: 30, date: "2023-10-05", isRejected: false }
  ] },
  { email: "john@vitstudent.ac.in", name: "JOHN DOE", role: "member", regNo: "23BCE9999", points: 10, departments: ["tech", "design"], locked: true, contributions: [] },
  { email: "jane@vitstudent.ac.in", name: "JANE SMITH", role: "member", regNo: "22BCE8888", points: 80, departments: ["webdev", "events"], locked: true, contributions: [] },
  { email: "alex@vitstudent.ac.in", name: "ALEX WONG", role: "member", regNo: "21BCE4444", points: 15, departments: ["social"], locked: true, contributions: [] },
  { email: "sarah@vitstudent.ac.in", name: "SARAH CONNOR", role: "member", regNo: "20BCE5555", points: 60, departments: ["tech"], locked: true, contributions: [] },
  { email: "mike@vitstudent.ac.in", name: "MIKE ROSS", role: "member", regNo: "21BCE6666", points: 5, departments: ["events"], locked: true, contributions: [] },
  { email: "lisa@vitstudent.ac.in", name: "LISA MONA", role: "member", regNo: "22BCE7777", points: 35, departments: ["design"], locked: true, contributions: [] }
];

const MOCK_PROJECTS = [
  { id: 1, title: "Website Revamp", brief: "Convert the Cyscom portal to a retro brutalist theme using React and Vite.", seatsTotal: 5, seatsFilled: 2, dept: "webdev", applicants: [] },
  { id: 2, title: "Annual Tech Symposium", brief: "Organize the main event for the tech department including speakers and logistics.", seatsTotal: 15, seatsFilled: 15, dept: "events", applicants: [] },
  { id: 3, title: "Social Media Campaign", brief: "Design posts and reels for the upcoming recruitment drive.", seatsTotal: 3, seatsFilled: 1, dept: "social", applicants: ["test@example.com"] },
  { id: 4, title: "Cybersecurity Workshop", brief: "Conduct a hands-on workshop on ethical hacking and network security.", seatsTotal: 8, seatsFilled: 4, dept: "tech", applicants: [] }
];

const MOCK_PENDING = [
  { id: 101, email: "test@example.com", description: "Created event poster", driveLink: "https://drive.google.com/...", status: "pending", submittedAt: "2023-10-10" },
  { id: 102, email: "john@vitstudent.ac.in", description: "Wrote blog post on React", driveLink: "https://drive.google.com/...", status: "pending", submittedAt: "2023-10-11" }
];

export default function App() {
  const [phase, setPhase] = useState("landing");
  const [tab, setTab] = useState("dashboard");
  const [users, setUsers] = useState(MOCK_USERS);
  const [projects, setProjects] = useState(MOCK_PROJECTS);
  const [pending, setPending] = useState(MOCK_PENDING);
  const [projectRequests, setProjectRequests] = useState([]);
  const [sessionEmail, setSessionEmail] = useState(null);
  const [sessionUserFallback, setSessionUserFallback] = useState(null);
  const [loginError, setLoginError] = useState("");
  const [ready, setReady] = useState(true);

  // Mock API logic replaced with direct state updates
  const refreshData = useCallback(async () => {
    // No-op for mock
  }, []);



  useEffect(() => {
    // Skip backend init for mock
  }, []);

  const currentUser = (users && sessionEmail ? users.find((u) => u.email === sessionEmail) : null) || sessionUserFallback;

  /* ── Tab Guard for Staff ── */
  useEffect(() => {
    if (currentUser) {
      if (currentUser.role === "super_admin" && tab !== "superadmin" && tab !== "leaderboard") {
        setTab("superadmin");
      } else if (currentUser.role === "admin" && tab !== "admin" && tab !== "leaderboard") {
        setTab("admin");
      }
    }
  }, [currentUser, tab]);

  async function handleLogin(payload) {
    setLoginError("");
    try {
      let emailToSet = payload.email;
      let roleToSet = payload.role;

      // Ensure user exists in mock users array
      if (!users.find(u => u.email === emailToSet)) {
        setUsers(prev => [...prev, {
          email: emailToSet,
          name: payload.name,
          role: roleToSet || "member",
          regNo: payload.regNo || "N/A",
          points: 0,
          departments: [],
          locked: false,
          contributions: []
        }]);
      }

      setSessionUserFallback({ ...payload, contributions: payload.contributions || [] });
      setSessionEmail(emailToSet);
      setPhase("app");
      setTab(roleToSet === "super_admin" ? "superadmin" : roleToSet === "admin" ? "admin" : "dashboard");
    } catch (err) {
      setLoginError(err.message);
    }
  }

  /* ── Logout ── */
  function handleLogout() {
    localStorage.removeItem("club:jwt");
    setSessionEmail(null);
    setSessionUserFallback(null);
    setUsers([]);
    setProjects([]);
    setPending([]);
    setProjectRequests([]);
    setPhase("landing");
    setTab("dashboard");
  }

  /* ── Departments ── */
  async function handleLockDepartments(selected) {
    setUsers(users.map(u => u.email === sessionEmail ? { ...u, departments: selected, locked: true } : u));
  }

  /* ── Project join request (member) ── */
  async function handleRequestJoin(projectId) {
    setProjectRequests([...projectRequests, { id: Date.now(), email: sessionEmail, projectId, status: "pending" }]);
  }

  /* ── Approve project request (admin / super_admin) ── */
  async function handleApproveRequest(reqId) {
    setProjectRequests(projectRequests.map(r => r.id === reqId ? { ...r, status: "approved" } : r));
  }

  /* ── Reject project request (admin / super_admin) ── */
  async function handleRejectRequest(reqId) {
    setProjectRequests(projectRequests.map(r => r.id === reqId ? { ...r, status: "rejected" } : r));
  }

  /* ── Project application (kept for legacy compat) ── */
  async function handleApply(projectId) {}

  /* ── Submit contribution (member) ── */
  async function handleSubmitContribution(payload) {
    setPending([...pending, { id: Date.now(), email: sessionEmail, ...payload, status: "pending", submittedAt: new Date().toISOString().split('T')[0] }]);
  }

  /* ── Approve contribution (admin / super_admin) ── */
  async function handleApproveContribution(submissionId, title, points) {
    setPending(pending.map(p => p.id === submissionId ? { ...p, status: "approved", awardedPoints: points } : p));
    const sub = pending.find(p => p.id === submissionId);
    if (sub) {
      setUsers(users.map(u => u.email === sub.email ? { 
        ...u, 
        points: u.points + points,
        contributions: [{ title, points, date: new Date().toISOString().split('T')[0] }, ...u.contributions]
      } : u));
    }
  }

  /* ── Reject contribution ── */
  async function handleRejectContribution(submissionId) {
    setPending(pending.map(p => p.id === submissionId ? { ...p, status: "rejected" } : p));
  }

  /* ── Toggle Leaderboard Exclusion (super_admin) ── */
  async function handleToggleLeaderboardExclusion(email) {
    setUsers(users.map(u => u.email === email ? { ...u, excluded: !u.excluded } : u));
  }

  /* ── Direct task points assignment ── */
  async function handleAssignDirectPoints(email, title, points) {
    setUsers(users.map(u => u.email === email ? { 
      ...u, 
      points: u.points + points,
      contributions: [{ title, points, date: new Date().toISOString().split('T')[0] }, ...u.contributions]
    } : u));
  }

  /* ── Update user department selection ── */
  async function handleUpdateUserDepartments(email, departments) {
    setUsers(users.map(u => u.email === email ? { ...u, departments } : u));
  }

  /* ── Project CRUD ── */
  async function handleAddProject(project) {
    setProjects([...projects, { ...project, id: Date.now() }]);
  }

  async function handleEditProject(updated) {
    setProjects(projects.map(p => p.id === updated.id ? updated : p));
  }

  async function handleDeleteProject(projectId) {
    if (window.confirm("Are you sure you want to delete this project?")) {
      setProjects(projects.filter(p => p.id !== projectId));
    }
  }

  /* ── Loading ── */
  if (!ready) {
    return (
      <div className="cg-root" style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
        <GlobalStyle />
        <div className="cg-label">INITIALIZING{"…"}</div>
      </div>
    );
  }

  return (
    <div className={`cg-root ${phase === "app" ? "cg-app-mode" : ""}`}>
      <GlobalStyle />

      {phase === "landing" && <Landing onEnter={() => setPhase("pixel")} />}
      {phase === "pixel" && <PixelTransition onDone={() => setPhase("login")} />}
      {phase === "login" && <Login onLogin={handleLogin} error={loginError} />}

      {(phase === "app" || phase === "login") && (
        <>
          <div className="cg-side-text left">
<pre>{`
  ____ __   __ ____   ____  ___   __  __ 
 / ___|\\ \\ / // ___| / ___|/ _ \\ |  \\/  |
| |     \\ V / \\___ \\| |   | | | || |\\/| |
| |___   | |   ___) | |___| |_| || |  | |
 \\____|  |_|  |____/ \\____|\\___/ |_|  |_|
`}</pre>
          </div>
          <div className="cg-side-text right">
<pre>{`
 _____  _____  ____  ____  
|  ___||  ___|/ ___|/ ___| 
| |_   | |_  | |    \\___ \\ 
|  _|  |  _| | |___  ___) |
|_|    |_|    \\____||____/ 
`}</pre>
          </div>
        </>
      )}

      {phase === "app" && (
        <>
          <Shell user={currentUser} tab={tab} setTab={setTab} onLogout={handleLogout}>
            {tab === "dashboard" && (
              <Dashboard
                user={currentUser}
                setTab={setTab}
                onSubmitContribution={handleSubmitContribution}
                pending={pending}
              />
            )}
            {tab === "departments" && <Departments user={currentUser} users={users} onLock={handleLockDepartments} />}
            {tab === "projects" && <Projects user={currentUser} projects={projects} projectRequests={projectRequests} onRequest={handleRequestJoin} />}
            {tab === "leaderboard" && <Leaderboard users={users} currentEmail={sessionEmail} />}
            {tab === "superadmin" && currentUser.role === "super_admin" && (
              <SuperAdmin
                users={users}
                projects={projects}
                pending={pending || []}
                projectRequests={projectRequests || []}
                currentEmail={sessionEmail}
                onApprove={handleApproveContribution}
                onReject={handleRejectContribution}
                onToggleExclusion={handleToggleLeaderboardExclusion}
                onAddProject={handleAddProject}
                onEditProject={handleEditProject}
                onDeleteProject={handleDeleteProject}
                onAssignPoints={handleAssignDirectPoints}
                onUpdateDepartments={handleUpdateUserDepartments}
                onApproveRequest={handleApproveRequest}
                onRejectRequest={handleRejectRequest}
              />
            )}
            {tab === "admin" && currentUser.role === "admin" && (
              <Admin
                users={users}
                projects={projects || []}
                pending={pending || []}
                projectRequests={projectRequests || []}
                currentEmail={sessionEmail}
                onApprove={handleApproveContribution}
                onReject={handleRejectContribution}
                onAssignPoints={handleAssignDirectPoints}
                onUpdateDepartments={handleUpdateUserDepartments}
                onApproveRequest={handleApproveRequest}
                onRejectRequest={handleRejectRequest}
              />
            )}
          </Shell>
        </>
      )}
    </div>
  );
}
